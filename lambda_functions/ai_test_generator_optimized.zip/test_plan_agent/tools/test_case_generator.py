"""
Test Case Generator Tool
Generates high-quality test cases based on requirements analysis and KB insights
"""

import json
import boto3
from typing import Dict, Any, List

class TestCaseGeneratorTool:
    """Tool for generating comprehensive test cases"""
    
    def __init__(self):
        self.name = "test_case_generator"
        self.description = """Generates comprehensive test cases based on:
- Functional requirements
- Edge cases
- Risk areas
- Knowledge base insights
Creates detailed test cases with steps, preconditions, and expected results."""
        
        self.bedrock_client = boto3.client('bedrock-runtime', region_name='eu-west-1')
        self.model_id = "eu.anthropic.claude-haiku-4-5-20251001-v1:0"
    
    def execute(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute test case generation - OPTIMIZED"""
        try:
            functional_reqs = input_data.get('functional_requirements', [])
            edge_cases = input_data.get('edge_cases', [])
            risk_areas = input_data.get('risk_areas', [])
            generation_options = input_data.get('generation_options', {})
            
            min_cases = generation_options.get('min_test_cases', 5)
            max_cases = generation_options.get('max_test_cases', 15)
            target_cases = (min_cases + max_cases) // 2
            
            # Simplified prompt - focus on essentials only
            # Handle both dict and string formats
            reqs_list = []
            for req in functional_reqs[:5]:
                if isinstance(req, dict):
                    req_text = req.get('requirement', str(req))[:100]
                else:
                    req_text = str(req)[:100]
                reqs_list.append(f"- {req_text}")
            
            reqs_summary = "\n".join(reqs_list)
            
            generation_prompt = f"""Genera {target_cases} casos de prueba para:

REQUERIMIENTOS:
{reqs_summary}

Formato JSON (SOLO JSON, sin explicaciones):
{{
  "test_cases": [
    {{
      "name": "nombre",
      "description": "descripción",
      "priority": "High|Medium|Low",
      "preconditions": "precondiciones",
      "expected_result": "resultado",
      "test_data": "datos",
      "steps": ["paso1", "paso2"]
    }}
  ]
}}"""
            
            # Optimized request - reduced tokens
            response = self.bedrock_client.invoke_model(
                modelId=self.model_id,
                body=json.dumps({
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 2000,  # Reduced from 4000
                    "temperature": 0.1,
                    "system": "Experto en testing. Responde SOLO con JSON válido.",
                    "messages": [{
                        "role": "user",
                        "content": generation_prompt
                    }]
                })
            )
            
            response_body = json.loads(response['body'].read())
            content = response_body['content'][0]['text']
            
            # Parse JSON
            result = self._extract_json(content)
            
            # Ensure we have test cases
            if not result.get('test_cases'):
                print("⚠️ No test cases generated, creating fallback")
                result['test_cases'] = self._create_fallback_cases(functional_reqs, target_cases)
            
            result['generation_completed'] = True
            result['total_generated'] = len(result.get('test_cases', []))
            
            return result
            
        except Exception as e:
            print(f"❌ Test case generation error: {str(e)}")
            import traceback
            traceback.print_exc()
            
            # Return fallback cases instead of empty
            return {
                "error": str(e),
                "generation_completed": False,
                "test_cases": self._create_fallback_cases(
                    input_data.get('functional_requirements', []),
                    generation_options.get('min_test_cases', 5)
                ),
                "total_generated": generation_options.get('min_test_cases', 5)
            }
    
    def _create_fallback_cases(self, functional_reqs: List, count: int) -> List[Dict[str, Any]]:
        """Create basic fallback test cases"""
        cases = []
        for i in range(min(count, len(functional_reqs) if functional_reqs else count)):
            req = functional_reqs[i] if i < len(functional_reqs) else {"requirement": f"Requirement {i+1}"}
            
            # Handle both dict and string formats
            if isinstance(req, dict):
                req_text = req.get('requirement', str(req))[:100]
            else:
                req_text = str(req)[:100]
            
            cases.append({
                "name": f"Test Case {i+1}: {req_text[:50]}",
                "description": f"Verify {req_text}",
                "priority": "Medium",
                "preconditions": "System accessible",
                "expected_result": "Functionality works as expected",
                "test_data": "Valid test data",
                "steps": [
                    "Navigate to feature",
                    "Execute test action",
                    "Verify result"
                ]
            })
        
        return cases
    
    def _extract_json(self, content: str) -> Dict[str, Any]:
        """Extract JSON from response - IMPROVED"""
        # Try direct parse first
        try:
            return json.loads(content)
        except:
            pass
        
        # Try to find JSON in markdown code blocks
        import re
        json_match = re.search(r'```(?:json)?\s*([\s\S]*?)\s*```', content)
        if json_match:
            try:
                return json.loads(json_match.group(1))
            except:
                pass
        
        # Try to find any JSON object
        json_match = re.search(r'\{[\s\S]*\}', content)
        if json_match:
            try:
                return json.loads(json_match.group(0))
            except:
                pass
        
        print(f"⚠️ Could not parse JSON from: {content[:200]}...")
        return {
            "test_cases": [],
            "recommendations": []
        }
